
module.exports = {
  sayHello: function() {
    console.log('Hello, World!');
  }
};


# My NPM Package

This is a sample npm package.

## Installation

```bash
npm install my-npm-package
```

## Usage

```javascript
const myPackage = require('my-npm-package');
myPackage.sayHello();
```
